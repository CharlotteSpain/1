from ipywidgets import *
w = HTML(value="Hello world!")
w.color = 'red'
w.background_color = 'yellow'
w
