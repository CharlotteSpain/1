from ipywidgets import *
from IPython.display import display
w = TextWidget(value="test")
display(w)
w.keys
